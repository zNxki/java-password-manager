package dev.znxki;

import dev.znxki.database.DatabaseManager;
import dev.znxki.models.PasswordEntity;
import dev.znxki.security.SecretCipher;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Scanner;

public final class Main {
    private static DatabaseManager database;

    static void main() throws Exception {
        database = new DatabaseManager();
        SecretCipher cipher = SecretCipher.fromEnv("CRYPTO_KEYS", "CRYPTO_ACTIVE_KEY");
        Scanner scanner = new Scanner(System.in);

        while (true) {
            clear();
            System.out.println("""
                    
                    1. Aggiungi account
                    2. Rimuovi account
                    3. Cerca account
                    4. Mostra tutti account
                    5. Esci
                    """);

            String input = ask(scanner, "Inserisci opzione", true);
            if (!isInteger(input)) {
                System.out.println("Non è un numero!");
                continue;
            }

            switch (Integer.parseInt(input)) {
                case 1 -> addAccount(scanner, cipher);

                case 5 -> {
                    return;
                }
                default -> System.out.println("Opzione non valida!");
            }
        }
    }

    private static void addAccount(Scanner scanner, SecretCipher cipher) throws Exception {
        String name = ask(scanner, "Inserisci nome dell'account", true);
        String username = ask(scanner, "Inserisci username", false);
        String password = ask(scanner, "Inserisci la password", true);
        String url = ask(scanner, "Inserisci url del sito", false);

        String encryptedPassword = cipher.encrypt(password, "user");
        PasswordEntity entity = new PasswordEntity(0, name, username, encryptedPassword, url, null);

        database.addAccount(entity)
                .thenAccept(_ -> {
                    System.out.println("Account salvato con successo!");

                    System.out.println("Premi un tasto per continuare...");
                    scanner.nextLine();
                })
                .exceptionally(e -> {
                    System.out.println("Errore nel salvataggio dell'account: " + e.getMessage());
                    return null;
                });

    }

    private static void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private static @Nullable String ask(@NotNull Scanner scanner, String label, boolean required) {
        String suffix = required ? "" : " ['salta' per saltare]";

        while (true) {
            System.out.println(label + suffix);
            System.out.print("> ");
            String input = scanner.nextLine();

            if (input.isBlank()) {
                System.out.println("Invalido!");
                continue;
            }

            if (!required && input.trim().equalsIgnoreCase("salta")) {
                return null;
            }

            return input;
        }
    }

    private static boolean isInteger(String str) {
        try {
            Integer.parseInt(str.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}