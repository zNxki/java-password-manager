package dev.znxki.database;

import dev.znxki.abstraction.Entity;
import dev.znxki.models.PasswordEntity;
import org.intellij.lang.annotations.Language;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DatabaseManager {
    private final static String DB_PATH = "./storage/database.db";

    private final Connection connection;
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    @Language("SQL")
    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                username TEXT,
                password TEXT NOT NULL,
                url TEXT,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            """;

    @Language("SQL")
    private static final String INSERT_ACCOUNT =
            "INSERT INTO accounts (name, username, password, url, notes) " +
                    "VALUES (?, ?, ?, ?, ?)";

    @Language("SQL")
    private static final String GET_PASSWORD_BY_ID =
            "SELECT * FROM accounts WHERE id = ?";

    @Language("SQL")
    private static final String GET_PASSWORD_BY_NAME =
            "SELECT * FROM accounts WHERE name = ?";

    @Language("SQL")
    private static final String GET_ACCOUNTS =
            "SELECT * FROM accounts";

    public DatabaseManager() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("JDBC driver don't found!");
        }

        try {
            File file = new File(DB_PATH.replace("/", File.separator));
            System.out.println(file.getAbsolutePath());
            if (!file.getParentFile().exists())
                file.getParentFile().mkdirs();

            if (!file.exists())
                file.createNewFile();

            this.connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
            initTables().exceptionally(e -> {
                System.err.println("Failed to initialize database tables");
                e.printStackTrace();
                return null;
            });
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private CompletableFuture<Void> initTables() {
        return execute(CREATE_TABLE);
    }

    public CompletableFuture<Void> addAccount(@NotNull PasswordEntity entity) {
        return execute(INSERT_ACCOUNT, entity.getName(), entity.getUsername(), entity.getPassword(), entity.getUrl(), entity.getNotes());
    }

    public CompletableFuture<PasswordEntity> getAccountById(int id) {
        return queryOne(GET_PASSWORD_BY_ID, PasswordEntity::sqlMapper, id);
    }

    public CompletableFuture<PasswordEntity> getAccountByName(@NotNull String name) {
        return queryOne(GET_PASSWORD_BY_NAME, PasswordEntity::sqlMapper, name.toLowerCase(Locale.ROOT));
    }

    public CompletableFuture<List<PasswordEntity>> getAccounts() {
        return query(GET_ACCOUNTS, PasswordEntity::sqlMapper);
    }

    public CompletableFuture<Void> execute(String sql, Object... parameters) {
        return CompletableFuture.runAsync(() -> {
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                setParameters(stmt, parameters);
                stmt.executeUpdate();
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, executor);
    }

    public <T> CompletableFuture<List<T>> query(String sql, RowMapper<T> mapper, Object... parameters) {
        return CompletableFuture.supplyAsync(() -> {
            List<T> results = new ArrayList<>();

            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                setParameters(stmt, parameters);

                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) results.add(mapper.map(rs));
                }
            } catch (SQLException e) {
                throw new CompletionException(e);
            }

            return results;
        }, executor);
    }

    public <T> CompletableFuture<T> queryOne(String sql, RowMapper<T> mapper, Object... parameters) {
        return CompletableFuture.supplyAsync(() -> {
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                setParameters(stmt, parameters);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (!rs.next()) return null;

                    return mapper.map(rs);
                }
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, executor);
    }

    private void setParameters(
            PreparedStatement stmt,
            Object @NotNull ... parameters
    ) throws SQLException {
        for (int i = 0; i < parameters.length; i++)
            stmt.setObject(i + 1, parameters[i]);
    }

    public void shutdown() {
        try {
            connection.close();
            executor.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}